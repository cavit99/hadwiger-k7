# An apex cycle gives a \(K_7\) minor

**Status:** written proof of the lemma below; no separate audit. The lemma does
not by itself prove the two-triangle neighbourhood or `HC_7`.

## Lemma

Let \(P=\{p_1,p_2,p_3\}\) and \(Q=\{q_1,q_2,q_3\}\) be disjoint triangles. Let
\(C\) be an odd cycle of length at least 3. Let \(r,u\) be distinct vertices
outside \(P\cup Q\cup V(C)\). Suppose that every vertex of \(C\) is complete
to \(P\) or complete to \(Q\), that \(r\) is adjacent to every vertex of
\(P\cup Q\cup V(C)\), and that \(u\) is adjacent to every vertex of
\(P\cup Q\) and to \(r\). Then the graph formed by these vertices and edges
has a \(K_7\) minor.

An alternating 4-cycle, which is even, need not have such a minor. The
argument uses that \(C\) is odd only to organise the mixed cases; the pure
case holds for every cycle length at least 3.

## Proof

Call a vertex of \(C\) a \(P\)-vertex or a \(Q\)-vertex according to the
triangle it dominates. Write \(n=|V(C)|\).

### Pure cycles

Suppose every vertex is a \(P\)-vertex. Label \(V(C)=\{0,1,\ldots,n-1\}\) in
order. Choose three pairwise adjacent connected pieces as follows.

- If \(n=3\), take three singletons.
- If \(n=4\), take \(\{0,1\}\), \(\{2\}\) and \(\{3\}\).
- If \(n\ge 5\), take \(A=\{0,1,n-1\}\), \(B=\{2\}\) and
  \(C_\ast=\{3,\ldots,n-2\}\).

The length-four pieces meet by the edge \(0\)–\(3\). The longer pieces meet
by \(1\)–\(2\), \(2\)–\(3\) and \((n-1)\)–\((n-2)\). The bags

\[
\{u,p_1\},\ \{p_2\},\ \{p_3\},\ \{r\},\ A,\ B,\ C_\ast
\]

are pairwise adjacent. Indeed \(u\) meets \(p_2\), \(p_3\) and \(r\), and
meets each piece through \(p_1\); each of \(p_2\), \(p_3\) and \(r\) meets
each piece because the pieces are complete to \(P\) and to \(r\). The
symmetric bags \(\{u,q_1\},\{q_2\},\{q_3\}\) handle a cycle of
\(Q\)-vertices.

### One vertex of one type, at least four of the other

By swapping the triangles it is enough to treat a single \(P\)-vertex.
Let \(n\ge 5\) and label \(C\) so that \(a_0\) is the \(P\)-vertex and
\(a_1,\ldots,a_{n-1}\) are \(Q\)-vertices in order. The seven bags

\begin{align*}
&\{u,p_2,p_3,q_1\},\\
&\{p_1,a_0,a_3,a_4,\ldots,a_{n-1}\},\\
&\{a_1\},\ \{a_2\},\ \{r\},\ \{q_2\},\ \{q_3\}
\end{align*}

are connected: \(u\) meets \(p_2\), \(p_3\) and \(q_1\), while
\(a_0a_{n-1}\cdots a_3\) is a path. They are pairwise adjacent.

- \(\{u,p_2,p_3,q_1\}\) meets \(\{p_1,a_0,\ldots\}\) through \(p_2p_1\), meets
  \(\{a_1\}\) and \(\{a_2\}\) through \(q_1\), meets \(\{r\}\) through \(u\),
  and meets \(\{q_2\}\) and \(\{q_3\}\) through \(u\).
- \(\{p_1,a_0,a_3,\ldots\}\) meets \(\{a_1\}\) through \(a_0a_1\) and
  \(\{a_2\}\) through \(a_3a_2\). It meets \(\{r\}\) through \(p_1\), and
  meets \(\{q_2\}\) and \(\{q_3\}\) because \(a_3\) is a \(Q\)-vertex.
- \(\{a_1\}\) meets \(\{a_2\}\) by the cycle edge. Each of \(a_1,a_2\) is a
  \(Q\)-vertex adjacent to \(r\), so both meet \(\{r\},\{q_2\},\{q_3\}\).
- \(\{r\}\) meets \(\{q_2\}\) and \(\{q_3\}\), and \(q_2q_3\) is an edge.

The case of a single \(Q\)-vertex and at least four \(P\)-vertices is
symmetric.

### The mixed triangle

The remaining cycles with a single minority vertex have length 3. Up to
swapping the triangles, the vertices \(a_0,a_1,a_2\) are of types \(P,P,Q\).
The bags

\begin{align*}
&\{p_1\},\ \{p_2\},\ \{p_3\},\\
&\{a_2,q_1,q_3,u\},\ \{q_2,r\},\ \{a_0\},\ \{a_1\}
\end{align*}

are pairwise adjacent. The triangle on \(P\) joins the three singletons.
The vertex \(u\) joins \(\{a_2,q_1,q_3,u\}\) to each of them, and \(r\) joins
\(\{q_2,r\}\) to each of them and to \(a_0\) and \(a_1\). The edge \(rq_1\)
joins \(\{q_2,r\}\) to \(\{a_2,q_1,q_3,u\}\). The cycle supplies
\(a_0a_1\), \(a_0a_2\) and \(a_1a_2\). Both \(a_0\) and \(a_1\) meet every
vertex of \(P\).

### Two \(P\)-vertices

Let \(n\ge 5\), so there are at least three \(Q\)-vertices. If the two
\(P\)-vertices \(a_0,a_1\) are adjacent, label the \(Q\)-vertices
\(a_2,\ldots,a_{n-1}\) in order along the rest of the cycle. The bags

\begin{align*}
&\{u,p_1\},\\
&\{p_2,a_0,a_3,a_4,\ldots,a_{n-1}\},\\
&\{p_3,a_1,a_2\},\\
&\{r\},\ \{q_1\},\ \{q_2\},\ \{q_3\}
\end{align*}

are connected: \(a_0\) meets the path \(a_{n-1}\cdots a_3\), and \(a_1a_2\)
is an edge. The vertex \(u\) joins \(\{u,p_1\}\) to \(r\) and to every
vertex of \(Q\), while \(p_1\) meets \(a_0\) and \(a_1\). The edge \(a_0a_1\)
joins the second bag to the third. The vertex \(a_3\) is a \(Q\)-vertex, so
the second bag meets every vertex of \(Q\) and meets \(r\); likewise \(a_2\)
joins the third bag to every vertex of \(Q\) and to \(r\). The triangle on
\(Q\) and the edges from \(r\) finish the pairs.

If the two \(P\)-vertices \(x,y\) are not adjacent, each of the two
\(x\)–\(y\) paths along \(C\) has a \(Q\)-vertex in its interior. Call those
paths, including \(x\) and \(y\) respectively and including their interior
\(Q\)-vertices, \(L\) and \(R\). Both interiors are nonempty. The bags

\[
\{u,p_1\},\ \{p_2\}\cup V(L),\ \{p_3\}\cup V(R),\ \{r\},\ \{q_1\},\ \{q_2\},\ \{q_3\}
\]

work. Each of \(L,R\) is connected, and the end of \(L\) next to \(y\) is
adjacent to \(y\in R\). The vertex \(u\) meets \(r\) and \(Q\), while \(p_1\)
meets the \(P\)-vertices \(x\) and \(y\). Each of \(L,R\) contains a
\(Q\)-vertex, so both middle bags meet every vertex of \(Q\) and meet \(r\).

### At least three \(P\)-vertices and at least two \(Q\)-vertices

If some cyclic sequence of three \(P\)-vertices has a \(Q\)-vertex in two of
the three intervening open arcs, cut \(C\) at those three \(P\)-vertices
into three contiguous arcs, each containing its initial \(P\)-vertex. Two
arcs then contain a \(Q\)-vertex. Place \(u\) in the remaining arc, which
still contains its \(P\)-vertex. The bags are \(\{u,p_1\}\) together with
that arc, \(\{p_2\}\) together with the second arc, \(\{p_3\}\) together
with the third, and the singletons \(\{r\},\{q_1\},\{q_2\},\{q_3\}\).
Consecutive arcs of a cover are pairwise adjacent. Each arc meets its
\(p_i\) through its \(P\)-vertex, the two arcs without \(u\) meet every
vertex of \(Q\) through a \(Q\)-vertex, and the arc with \(u\) meets every
vertex of \(Q\) through \(u\). The vertex \(r\) meets every bag.

Otherwise every \(Q\)-vertex lies in a single gap, so the \(P\)-vertices
form one contiguous block \(c_1,\ldots,c_\alpha\) with \(\alpha\ge 3\) and
the \(Q\)-vertices form one contiguous block \(d_1,\ldots,d_\beta\) with
\(\beta\ge 2\). The three arcs

\[
\{c_2\},\qquad \{c_3,\ldots,c_\alpha,d_1\},\qquad \{d_2,\ldots,d_\beta,c_1\}
\]

partition \(C\). They are connected, and the boundary edges \(c_1c_2\),
\(c_2c_3\) and \(d_1d_2\) make them pairwise adjacent. The bags

\begin{align*}
&\{u,p_1,c_2\},\\
&\{p_2,c_3,\ldots,c_\alpha,d_1\},\\
&\{p_3,d_2,\ldots,d_\beta,c_1\},\\
&\{r\},\ \{q_1\},\ \{q_2\},\ \{q_3\}
\end{align*}

are the required minor. The vertex \(c_2\) meets \(p_1\), the block
\(c_3\cdots d_1\) meets \(p_2\), and \(c_1\) meets \(p_3\). The edges
\(c_1c_2\), \(c_2c_3\) and \(d_1d_2\) join the first three bags. The vertex
\(u\) joins the first bag to \(r\) and to every vertex of \(Q\). The
\(Q\)-vertices \(d_1\) and \(d_2\) join the second and third bags to every
vertex of \(Q\) and to \(r\).

Every odd cycle falls into one of these classes. \(\square\)

## Where the lemma meets the critical host

Let \(G\) be seven-connected, seven-chromatic and \(K_7\)-minor-free, with
every proper minor six-colourable, and with
\(N(u)=P\cup Q\cup\{r\}\) the two-triangle neighbourhood. The prism theorem
supplies the induced prism and the maximum helper \(E\). Its critical-host
section supplies the neighbour counts and the locality of non-cut vertices
of \(E\).

Colour the prism with \(\{1,2,3\}\) so that both ends of the \(i\)-th
vertical path receive colour \(i\). This extends along every vertical path
of even length, and then every three consecutive vertices of such a path
use only two colours. Give \(r\) colour \(4\). A vertex of \(E\) keeps
colours \(5\) and \(6\) available, keeps colour \(4\) unless it is adjacent
to \(r\), and keeps a colour in \(\{1,2,3\}\) unless that colour meets it on
the prism.

Let \(Z\) be the vertices of \(E\) adjacent to \(r\) that meet all three
prism colours. If \(E\) is 2-connected, locality puts every vertex of \(Z\)
complete to \(P\) or complete to \(Q\). An odd cycle in \(Z\) is then a
cycle of the kind treated above, and \(G\) has a \(K_7\) minor.

If \(Z\) is bipartite, the cross edges between the two kinds of apex and the
set of apexes outside the neighbourhood of \(r\) that meet both shores of one
component of \(Z\) are controlled by the minor lemmas in
[the bipartite-helper note](hc7_two_triangle_bipartite_helper.md). That note
colours \(Z\) by \(\{5,6\}\) and that set by \(4\), and leaves a nonempty
residual list at every other vertex of \(E\). Colouring those residual lists,
odd-length vertical paths, and a cut vertex of \(E\) are not treated here.
