# Bipartite apexes in the even two-triangle helper

**Status:** written proofs of the minor lemmas and of the precolouring
below. No separate audit. The residual list colouring of the helper is
still open, so this does not prove the two-triangle neighbourhood or `HC7`.

The host is the critical one from the
[prism theorem](../results/hc7_two_triangle_extremal_prism.md): \(G\) is
seven-connected, seven-chromatic and \(K_7\)-minor-free, every proper minor
is six-colourable, and \(N(u)=P\cup Q\cup\{r\}\) with \(P\) and \(Q\)
anticomplete triangles and \(r\) complete to both. The induced prism and the
maximum helper \(E\) are those of that theorem, \(E\) is 2-connected, and
every vertical path has even length. An apex is a vertex of \(E\) complete
to \(P\) or complete to \(Q\).

## Lists

Colour the prism by \(\{1,2,3\}\) so that \(p_i\) and \(q_i\) receive colour
\(i\) and each vertical path is properly 2-coloured. This is possible because
every vertical path has even length. Give \(r\) colour \(4\). Every vertex of
\(E\) keeps \(\{5,6\}\) available: \(u\) is adjacent only to \(P\cup Q\cup\{r\}\).
A vertex of \(E\) keeps colour \(4\) unless it is adjacent to \(r\), and keeps
a colour in \(\{1,2,3\}\) unless the prism meets it in that colour.

Let \(Z\) be the set of vertices of \(E\) whose list is exactly \(\{5,6\}\).
Such a vertex is adjacent to \(r\) and meets all three prism colours. By the
locality clause of the prism theorem, its prism neighbours lie in \(P\), in
\(Q\), or in a segment of at most two edges of one vertical path. An even
2-coloured segment uses only two colours, so every vertex of \(Z\) is complete
to \(P\) or complete to \(Q\).

Let \(A_4\) be the set of apexes that are not adjacent to \(r\). Each has list
\(\{4,5,6\}\). Write \(S^\ast\) for the vertices of \(A_4\) that have, in some
single component of \(Z\), neighbours on both shores of that component.

## Two disjoint cross edges

Call an edge of \(E\) a cross edge when it joins an apex complete to \(P\) to
an apex complete to \(Q\).

**Lemma 1.** Let \(a,b\) be apexes complete to \(P\) and let \(c,d\) be apexes
complete to \(Q\), all four distinct, with edges \(ac\) and \(bd\). Then \(G\)
has a \(K_7\) minor.

**Proof.** The bags

\[
\{u,p_1\},\ \{r,p_2\},\ \{p_3,b,d\},\ \{q_1\},\ \{q_2\},\ \{q_3\},\ \{a,c\}
\]

are connected: \(u\sim p_1\), \(r\sim p_2\), \(b\sim p_3\) and \(b\sim d\), and
\(a\sim c\). They are pairwise adjacent.

- \(\{u,p_1\}\) meets \(\{r,p_2\}\) by \(ur\) and \(p_1p_2\), meets
  \(\{p_3,b,d\}\) by \(p_1p_3\) and \(p_1b\), meets each \(\{q_i\}\) by \(u\),
  and meets \(\{a,c\}\) by \(p_1a\).
- \(\{r,p_2\}\) meets \(\{p_3,b,d\}\) by \(rp_3\) and \(p_2b\), meets each
  \(\{q_i\}\) by \(r\), and meets \(\{a,c\}\) by \(p_2a\).
- \(\{p_3,b,d\}\) meets each \(\{q_i\}\) by \(d\), and meets \(\{a,c\}\) by
  \(p_3a\).
- The triangle on \(Q\) joins \(\{q_1\},\{q_2\},\{q_3\}\), and \(c\) joins
  \(\{a,c\}\) to each of them.

Thus these bags are a \(K_7\) minor. \(\square\)

In a \(K_7\)-minor-free host the cross edges therefore have matching number at
most 1, so they all share a common endpoint.

## Four mutual apexes

**Lemma 2.** Any four pairwise adjacent apexes form a \(K_7\) minor with
\(P\), \(Q\), \(u\) and \(r\).

**Proof.** If all four are complete to \(P\), they form a \(K_4\) joined
completely to the triangle \(P\), which is a \(K_7\) subgraph. The same holds
with \(Q\) in place of \(P\).

If \(a,b,c\) are complete to \(P\) and \(d\) is complete to \(Q\), the bags

\[
\{p_1\},\ \{p_2\},\ \{p_3\},\ \{a\},\ \{b\},\ \{c\},\ \{u,q_1,d\}
\]

work. The set \(\{u,q_1,d\}\) is connected by \(uq_1\) and \(q_1d\). It meets
each of \(\{a\},\{b\},\{c\}\) by the \(K_4\) edges at \(d\), and it meets each
of \(\{p_i\}\) by \(u\). The remaining pairs are edges of \(P\) or of the
\(K_4\), or the complete join from \(\{a,b,c\}\) to \(P\).

If exactly two are complete to \(P\), label them \(a,b\) and label the two
complete to \(Q\) by \(c,d\). The four cross edges of the \(K_4\) include the
two disjoint edges \(ac\) and \(bd\). Lemma 1 applies. \(\square\)

## A double-shore path

Throughout this section every named \(z_i\) is an apex complete to \(P\),
adjacent to \(r\), and the edges \(z_0z_1\cdots z_m\) are present. The vertex
\(a\) is complete to \(P\). The integer \(m\) is odd and at least 1, and
\(a\sim z_0\), \(a\sim z_m\).

**Lemma 3.** Suppose \(b\) is complete to \(P\) and \(a\sim b\). Suppose \(b\)
has a neighbour in \(\{z_0,\ldots,z_m\}\) or a neighbour \(w\), also complete
to \(P\) and adjacent to \(r\), outside that path. Then \(G\) has a \(K_7\)
minor, except that the minor need not exist when \(m=1\), the only neighbour
of \(b\) among these vertices is exactly one of \(z_0,z_1\), and \(b\) has no
further neighbour of this kind. That exceptional graph on
\(\{a,b,z_0,z_1\}\cup P\cup Q\cup\{u,r\}\) has no \(K_7\) minor.

**Proof.** The exceptional graph was checked by enumerating every choice of
seven root vertices and every assignment of the other five vertices to those
bags or to the complement. No model exists. The remaining cases are as
follows.

If \(m=1\) and \(b\) has a neighbour \(w\) outside \(\{z_0,z_1\}\), the bags

\[
\{p_1\},\ \{p_2\},\ \{p_3\},\ \{z_0\},\ \{z_1\},\ \{a\},\ \{r,b,w\}
\]

work. Here \(\{r,b,w\}\) is connected by \(bw\) and \(wr\). The vertex \(a\)
meets \(z_0\), \(z_1\) and \(b\); each of \(z_0,z_1,w\) meets \(r\) and every
vertex of \(P\); and \(z_0z_1\) is an edge.

If \(m=1\) and \(b\) meets both \(z_0\) and \(z_1\), then
\(\{a,b,z_0,z_1\}\) is a clique of apexes complete to \(P\). Lemma 2 gives the
minor.

Now suppose \(m\ge 3\). If \(b\) has a neighbour \(w\) outside the path, the
bags

\[
\{p_1\},\ \{p_2\},\ \{p_3\},\ \{a,z_0\},\ \{z_1,\ldots,z_{m-1}\},\ \{z_m\},\ \{r,b,w\}
\]

work. The middle set is a subpath. The set \(\{r,b,w\}\) is connected by
\(bw\) and \(wr\). Adjacencies: \(z_0z_1\) and \(z_{m-1}z_m\) meet the middle,
\(a\sim z_m\), \(a\sim b\), and \(r\) meets every \(z_i\) and \(w\). Every bag
meets every vertex of \(P\), through \(a\), \(b\), a vertex \(z_i\), or \(r\).

If every neighbour of \(b\) on this kind of vertex lies on the path, pick one,
say \(z_k\). If \(1\le k\le m-1\), the bags

\[
\{p_1\},\ \{p_2\},\ \{p_3\},\ \{r\},\ 
\{a,z_0,\ldots,z_{k-1}\},\ \{b,z_k\},\ \{z_{k+1},\ldots,z_m\}
\]

work. The two outer sets are subpaths through \(a\sim z_0\) and through the
path order. They meet each other by \(a\sim z_m\), the first meets
\(\{b,z_k\}\) by \(ab\) and by \(z_{k-1}z_k\), and \(\{b,z_k\}\) meets the last
by \(z_kz_{k+1}\). The vertex \(r\) meets every bag through \(z_0\), \(z_k\) or
\(z_m\), and through \(p_1,p_2,p_3\).

If \(k\in\{0,m\}\), say \(b\sim z_0\), the bags

\[
\{p_1\},\ \{p_2\},\ \{p_3\},\ \{b,z_0\},\ \{a,z_m\},\ \{z_1,\ldots,z_{m-1}\},\ \{r\}
\]

work. The middle is nonempty because \(m\ge 3\). It meets \(\{b,z_0\}\) by
\(z_0z_1\) and meets \(\{a,z_m\}\) by \(z_{m-1}z_m\). Those two bags meet by
\(ab\), and \(r\) meets each of them through \(z_0\) or \(z_m\). \(\square\)

The same statements hold with \(P\) and \(Q\) exchanged.

One further path occurs when the common endpoint of the cross edges lies in
\(Z\) and is complete to \(Q\). A direct path through that vertex alone, from
one apex complete to \(P\) to another, has even length. An odd path through
it has the following minor.

**Lemma 3a.** Let \(zw\) be a path in \(Z\) of odd length at least 3, with
ends \(z\) and \(w\) complete to \(P\). Suppose the path contains a vertex
\(x\) complete to \(Q\), every other vertex of the path is complete to \(P\),
and every vertex of the path is adjacent to \(r\). Let \(a\) be complete to
\(P\), with \(a\sim z\) and \(a\sim w\). Then the bags

\[
\{u,p_1,q_3\},\ \{p_2\},\ \{p_3\},\ \{r,q_1\},\ 
M\cup\{q_2\},\ \{a,w\},\ \{z\}
\]

are a \(K_7\) minor, where \(M\) is the set of internal vertices of the path.
The set \(M\) is a nonempty subpath because the path has length at least 3,
and it contains \(x\), so \(M\cup\{q_2\}\) is connected by the subpath and the
edge \(xq_2\). The end \(z\) meets \(M\), and \(w\) meets \(M\). The edge
\(az\) joins \(\{a,w\}\) to \(\{z\}\), and \(a\sim w\). The vertex \(r\) joins
\(\{r,q_1\}\) to \(\{z\}\), to \(\{a,w\}\) and to \(M\). The vertex \(u\) meets
\(p_2\), \(p_3\) and \(r\). The vertex \(x\) meets every vertex of \(Q\), and
every vertex of \(M\cup\{z,w\}\) other than \(x\) meets every vertex of \(P\).
The symmetric statement, with the two triangles exchanged, has the same proof.
\(\square\)

## The set \(S^\ast\) is independent

**Lemma 4.** Let \(b\) be an apex complete to \(Q\), and let \(z_0\ldots z_m\)
be a path of odd length \(m\ge 3\) in \(Z\), each vertex complete to \(Q\) and
adjacent to \(r\), with \(b\sim z_0\) and \(b\sim z_m\). Let \(a\) be an apex
complete to \(P\) and adjacent to \(b\). Then \(G\) has a \(K_7\) minor.

**Proof.** The bags

\[
\{q_1\},\ \{q_2\},\ \{q_3\},\ \{b,z_0\},\ \{z_1,\ldots,z_{m-1}\},\ \{z_m\},\ \{p_1,a,r\}
\]

are connected: the path supplies the middle, \(b\sim z_0\), and
\(\{p_1,a,r\}\) is connected by \(ap_1\) and \(p_1r\). The middle meets
\(\{b,z_0\}\) and \(\{z_m\}\) by path edges, and \(b\sim z_m\). The vertex \(r\)
meets \(b\)'s bag and the middle and \(\{z_m\}\) through the vertices \(z_i\),
and \(a\sim b\) meets \(\{b,z_0\}\). Each \(\{q_i\}\) meets \(\{b,z_0\}\), the
middle and \(\{z_m\}\) because those vertices are complete to \(Q\), and meets
\(\{p_1,a,r\}\) by \(r\). The triangle on \(Q\) finishes the pairs. \(\square\)

For a witness of length 1 the same conclusion is the following.

**Lemma 5.** Let \(b,z_0,z_1\) be apexes complete to \(Q\), with \(z_0\sim z_1\),
\(b\) adjacent to both, and both \(z_i\) adjacent to \(r\). Let \(a\) be an
apex complete to \(P\) and adjacent to \(b\). Then the bags

\[
\{q_1\},\ \{q_2\},\ \{q_3\},\ \{z_0\},\ \{z_1\},\ \{b\},\ \{p_1,a,r\}
\]

are a \(K_7\) minor. The set \(\{p_1,a,r\}\) is connected by \(ap_1\) and
\(p_1r\). It meets \(\{b\}\) by \(ab\) and meets \(z_0,z_1\) and every \(q_i\)
by \(r\). The vertices \(b,z_0,z_1\) are pairwise adjacent and complete to \(Q\).
\(\square\)

**Lemma 5a.** Let \(z_0\ldots z_m\) be a path of odd length \(m\ge 1\) whose
vertices are complete to \(P\) and adjacent to \(r\). Let \(b\) be complete to
\(Q\), with \(b\sim z_0\) and \(b\sim z_m\), and let \(a\) be complete to \(P\)
with \(a\sim b\). Then the bags

\[
\{u,p_1,q_3\},\ \{p_2\},\ \{p_3\},\ \{r,q_1\},\ \{a,b,q_2\},\ \{z_0\},\ \{z_1,\ldots,z_m\}
\]

are a \(K_7\) minor. The set \(\{a,b,q_2\}\) is connected by \(ab\) and \(bq_2\).
The set \(\{z_1,\ldots,z_m\}\) is a subpath, nonempty because \(m\ge 1\), and
\(z_0z_1\) joins it to \(\{z_0\}\). The vertex \(b\) meets \(\{z_0\}\) and meets
\(\{z_1,\ldots,z_m\}\) at \(z_m\). The vertex \(r\) meets both path bags and
meets \(q_1\). The vertex \(u\) meets \(p_2\), \(p_3\) and \(r\). The vertex
\(a\) meets \(p_1,p_2,p_3\), and \(b\) meets every vertex of \(Q\), so
\(\{a,b,q_2\}\) meets \(\{u,p_1,q_3\}\), \(\{r,q_1\}\) and both path bags.
Each path bag meets \(\{u,p_1,q_3\}\) through \(p_1\) and meets
\(\{r,q_1\}\) through \(r\). \(\square\)

**Theorem 6.** In the \(K_7\)-minor-free host, \(S^\ast\) is an independent
set.

**Proof.** The apex-cycle lemma of `hc7_apex_cycle_k7.md` says that an odd
cycle in \(Z\) is a \(K_7\) minor. Thus \(Z\) is bipartite, and the same holds
for the subgraph induced by the apexes in \(Z\) that are complete to \(P\),
and for those complete to \(Q\).

By Lemma 1 every cross edge shares a common endpoint \(x\). Consider an edge
of \(S^\ast\).

Suppose first that \(a,b\in S^\ast\) are both complete to \(P\). The common
endpoint \(x\) of the cross edges is not in \(S^\ast\) unless it fails to meet
\(r\). Every vertex of \(S^\ast\) lies in \(A_4\), so it is not adjacent to
\(r\). If \(x\) is adjacent to \(r\), then \(x\notin S^\ast\), and neither
\(a\) nor \(b\) has a cross edge. If \(x\) is not adjacent to \(r\), then \(x\)
may be one of \(a,b\); the other has no cross edge.

In all of these subcases every \(Z\)-neighbour of a vertex of \(\{a,b\}
\setminus\{x\}\) is complete to \(P\). A simple path in \(Z\) between two such
neighbours uses a cross edge only if that edge meets \(x\). If \(x\notin Z\),
then \(Z\) contains no cross edge and the path stays among apexes complete to
\(P\). If \(x\in Z\) is complete to \(P\), a step from \(x\) to an apex
complete to \(Q\) can return to a new apex complete to \(P\) only by visiting
\(x\) again, so a simple path never does so. If \(x\in Z\) is complete to
\(Q\), the only cross edges inside \(Z\) touch \(x\). A simple path between
two apexes complete to \(P\) that uses such an edge therefore contains \(x\)
internally and has all its other vertices complete to \(P\). If that path has
odd length at least 3, Lemma 3a supplies a \(K_7\) minor together with the
vertex of \(S^\ast\) adjacent to both ends. A path of length 1 is an ordinary
edge and does not contain \(x\).

Since \(a\in S^\ast\), some component of \(Z\) contains neighbours of \(a\) on
both shores. The mixed shape is a minor, so the host supplies a path of the
first kind. The same holds for \(b\), and therefore \(b\) has a neighbour in
the pure side \(Z_P\).

Lemma 3 then gives a \(K_7\) minor. The exceptional graph of that lemma does
not put \(b\) in \(S^\ast\), because \(b\) meets only one shore of the single
edge \(z_0z_1\). This contradicts the host. The symmetric argument applies
when both vertices are complete to \(Q\).

Suppose \(a\in S^\ast\) is complete to \(P\) and \(b\in S^\ast\) is complete to
\(Q\), with \(a\sim b\). The edge \(ab\) is a cross edge, so the common
endpoint \(x\) is \(a\) or \(b\).

If \(x=a\), no cross edge leaves \(b\) for an apex complete to \(P\). Every
\(Z\)-neighbour of \(b\) is therefore complete to \(Q\). As in the previous
paragraph, the host supplies a witness path of \(b\) in that side of \(Z\): a
mixed path would already be a minor by the symmetric form of Lemma 3a. Lemmas
4 and 5, according to the length of that path, give a \(K_7\) minor.

If \(x=b\), no cross edge leaves \(a\). The same reasoning supplies a witness
path of \(a\) in the side complete to \(P\). It also supplies, for \(b\),
either a witness path in the side complete to \(Q\), in which case Lemmas 4
and 5 apply, or a witness path in the side complete to \(P\). There is no
cross edge inside \(Z\), because every cross edge meets \(b\) and \(b\notin Z\).
A witness of \(b\) on the side complete to \(P\) is therefore a pure path, and
Lemma 5a gives the minor. \(\square\)

## The precolouring

**Theorem 7.** In the \(K_7\)-minor-free host one may colour \(Z\) properly by
\(\{5,6\}\) and then colour \(S^\ast\) by \(4\). The colouring is proper, every
coloured vertex receives a colour from its list, and every uncoloured vertex
of \(E\) keeps at least one available colour.

**Proof.** Bipartiteness of \(Z\) gives the colouring by \(\{5,6\}\). Theorem 6
says \(S^\ast\) is independent, so colour \(4\) is proper on \(S^\ast\). No
vertex of \(S^\ast\) is adjacent to \(r\), and the prism forbids
\(\{1,2,3\}\) on \(A_4\), so \(4\) lies in every list on \(S^\ast\). Vertices
of \(Z\) use only \(\{5,6\}\), so edges between \(Z\) and \(S^\ast\) are
proper.

Let \(y\in E\setminus(Z\cup S^\ast)\). If some colour \(\gamma\in\{1,2,3\}\)
lies in the list of \(y\), that colour is unused on \(Z\cup S^\ast\) and
survives. Otherwise \(y\in A_4\), with list \(\{4,5,6\}\), and \(y\notin S^\ast\).

The coloured vertices use only \(\{4,5,6\}\). Colour \(4\) is lost only through
a neighbour in \(S^\ast\), and a colour in \(\{5,6\}\) is lost only through a
neighbour in \(Z\). If \(y\) fails to meet \(S^\ast\), colour \(4\) survives.
If \(y\) meets \(S^\ast\) but has no \(Z\)-neighbour of one colour in
\(\{5,6\}\), that colour survives, since \(S^\ast\) does not use it.

Suppose \(y\) meets some \(s\in S^\ast\) and also meets both colours on \(Z\).
The proofs of Theorem 6 produce a pure witness path of \(s\). If \(y\) and
\(s\) are complete to the same triangle, Lemma 3 applies to that path once
\(y\) has a neighbour on the corresponding side of \(Z\). Both colours supply
such a neighbour. When the witness is a single edge and every neighbour of
\(y\) on that side lies at one endpoint, \(y\) sees only one colour there, so
the other colour is a neighbour off the edge, which is the outside-neighbour
case of Lemma 3. If \(y\) and \(s\) are complete to opposite triangles, Lemmas
4, 5 and 5a apply exactly as in the mixed case of Theorem 6, with \(y\) in
the role of the vertex adjacent to \(s\). Each alternative is a \(K_7\) minor.
Thus this last possibility does not occur, and colour \(4\) survives.
\(\square\)

Giving \(u\) colour \(5\) is proper once \(E\) has been coloured from the
residual lists: \(u\) meets only \(P\cup Q\cup\{r\}\), coloured in
\(\{1,2,3,4\}\).

## Minors that meet the residual lists

The two smallest graphs which refuse the lists on a single apex side, while
keeping \(S^\ast\) independent, both embed in the host as \(K_7\) minors.

**Lemma 8.** Let \(a\) and \(b\) be adjacent apexes complete to \(P\), and let
\(z_1,z_2\) be apexes complete to \(P\) and adjacent to \(r\), not necessarily
adjacent to each other. Suppose both \(a\) and \(b\) are adjacent to both
\(z_1\) and \(z_2\). Then the bags

\[
\{p_1\},\ \{p_2\},\ \{p_3\},\ \{a\},\ \{b\},\ \{z_1\},\ \{r,z_2\}
\]

are a \(K_7\) minor. The set \(\{r,z_2\}\) is connected by \(rz_2\). Both
\(a\) and \(b\) meet it through \(z_2\) and meet \(\{z_1\}\) through \(z_1\).
The edge \(ab\) joins \(\{a\}\) to \(\{b\}\), and \(z_1r\) joins \(\{z_1\}\) to
\(\{r,z_2\}\). Every one of \(a,b,z_1,z_2\) meets every vertex of \(P\), and
\(r\) does as well. \(\square\)

Thus, in the host, the common neighbourhood of any two vertices of the
\(P\)-side of \(Z\) is an independent set. The same holds on the \(Q\)-side.

**Lemma 9.** Let \(a,b,c\) be pairwise adjacent apexes complete to \(P\).
Suppose that each of them is adjacent to \(r\), or has a neighbour in the
\(P\)-side of \(Z\) which is not one of \(a,b,c\). Then \(G\) has a \(K_7\)
minor.

**Proof.** For each vertex among \(a,b,c\) that is not adjacent to \(r\),
choose such a neighbour, and let \(N\) be the set of chosen neighbours. The
bags

\[
\{p_1\},\ \{p_2\},\ \{p_3\},\ \{a\},\ \{b\},\ \{c\},\ \{r\}\cup N
\]

are connected: each chosen neighbour meets \(r\). A vertex of the triangle
that is adjacent to \(r\) meets the last bag through \(r\). A vertex that is
not adjacent to \(r\) meets it through its chosen neighbour. The triangle
edges join \(\{a\},\{b\},\{c\}\), and every triangle vertex is complete to
\(P\). \(\square\)

In particular, three mutual apexes complete to \(P\), each with a neighbour
in the \(P\)-side of \(Z\), form a \(K_7\) minor. A triangle in which only one
vertex is adjacent to \(r\), and the other two have no neighbour in \(Z\)
outside the triangle, need not: the graph on those three vertices together
with \(P\), \(Q\), \(u\) and \(r\) has no \(K_7\) minor.

The same two lemmas hold with \(P\) and \(Q\) exchanged.

**Lemma 10.** Let \(C\) be a cycle of length at least 3 whose vertices are
apexes complete to \(P\). Suppose each vertex of \(C\) is adjacent to \(r\) or
has a neighbour, not on \(C\), in the \(P\)-side of \(Z\). Then \(G\) has a
\(K_7\) minor.

**Proof.** Choose one such neighbour for every vertex of \(C\) that is not
adjacent to \(r\), and let \(N\) be the set of chosen neighbours. Label
\(C\) by \(0,1,\ldots,n-1\) in order and split it into three nonempty
connected pieces

\[
\begin{cases}
\{0\},\{1\},\{2\} & \text{if }n=3,\\
\{0,1\},\{2\},\{3\} & \text{if }n=4,\\
\{0,1\},\{2\},\{3,\ldots,n-1\} & \text{if }n\ge 5.
\end{cases}
\]

Consecutive pieces meet by a cycle edge, and the first meets the third by the
edge \(0(n-1)\). The bags are \(\{p_1\},\{p_2\},\{p_3\}\), the three pieces,
and \(\{r\}\cup N\). The last bag is connected because every vertex of \(N\)
meets \(r\). Each piece meets it: a vertex of the piece that is adjacent to
\(r\) meets \(r\), and a vertex that is not meets its chosen neighbour in
\(N\). Every piece meets every vertex of \(P\). \(\square\)

The hypothesis asks for an off-cycle neighbour because a portal that already
lies on \(C\) need not put every piece in contact with \(r\). A triangle with
only one vertex adjacent to \(r\), recorded above, is a cycle of this weaker
kind and has no \(K_7\) minor.

The same statements hold with \(P\) and \(Q\) exchanged. The residual list
colouring of \(E\setminus(Z\cup S^\ast)\) is still open. Odd-length vertical
paths and a cut vertex of \(E\) are not treated here.
