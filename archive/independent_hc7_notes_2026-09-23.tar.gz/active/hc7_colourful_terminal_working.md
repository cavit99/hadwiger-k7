# The four-connected colourful terminal

**Status:** working deduction; no separate audit. This does not prove the
terminal, either exceptional degree-seven neighbourhood, or `HC_7`.

The target is the unproved terminal of the
[colourful-pair reduction](../results/hc7_two_triangle_colourful_reduction.md):
every four-connected five-colourable graph with a colourful union of two
disjoint literal triangles has a `K5` model meeting that union. Colourful
means that every proper five-colouring uses all five colours on the six
vertices. The note
[on four Kempe bags](hc7_repeated_pair_k4_fifth_bag.md) is not an input.

## Lemma. A bipartite helper admits a deficient colouring

Let `H` be a finite simple graph whose vertices partition into `E`, `P`,
`Q`, `C1`, `C2`, `C3` as in the
[prism theorem](../results/hc7_two_triangle_extremal_prism.md): `P` and `Q`
are disjoint triangles, `H-E` is an induced triangular-prism subdivision
with vertical paths of length at least two, and there is no edge of `H`
between `P` and `Q`. If `E` is bipartite, then `H` has a proper
five-colouring in which `P union Q` receives at most three colours.

### Proof

Label `P={p0,p1,p2}` and `Q={q0,q1,q2}` so that the vertical path `Ri`
joins `pi` to `qi`. Colour `pi` and `qi` with colour `i`. Both triangles
are properly coloured, and together they use only `{0,1,2}`. Each vertical
path has length at least two and equal endpoint colours, so it extends to
a proper colouring with `{0,1,2}`.

The neighbours of any vertex of `E` on the prism receive colours in
`{0,1,2}`. Colour one part of `E` with colour `3` and the other with colour
`4`. The colouring is proper, and `P union Q` misses colours `3` and `4`.
\(\square\)

Thus, in a colourful anticomplete graph to which the prism theorem applies,
the helper is not bipartite.

## Two steps of the proposed route that are not proved

**Cross edges.** The four-path scheme does not eliminate a cross edge in a
minimal counterexample. If `p0` and `q0` share a colour and `p1q1` is a
cross edge, the two demands from `{p1,p2}` into `q0` use colour `0`. The
vertex `p0` lies on those Kempe components and the swap need not delete a
colour from the six vertices. On six vertices the only colourful
four-connected examples with a cross edge are `K6` minus one edge, nine
graphs up to labelling the missing edge, each of which has a `T`-meeting
`K5` for an elementary reason. That finite check is not a reduction.

**Odd cycles in the helper.** The locality statement that a non-cut vertex
of `E` meets only one triangle or one short segment of one vertical path is
proved in the prism note under the critical-host counts: at least two
`E`-neighbours at each triangle vertex and at least four at each internal
vertex. A four-connected terminal has minimum degree four, so a triangle
vertex need have only one `E`-neighbour and an internal vertex only two.
The exchange and the odd-cycle model that call on that locality are not
available until those counts are proved, or the argument is rewritten
without them.
