# Two-vertex cell on the P-edge of a minimum four-root reserve

**Status:** working construction, checked on the explicit branch sets
below. Not separately audited. This does not close the split-clique
neighbourhood or HC7. It produces a `K7` minor from one two-vertex cell
in a minimum four-root reserve, under a path or gate-contact hypothesis
recorded after the models.

Nothing here relies on the oriented partition of `M` in the
[split-clique construction](hc7_split_clique_construction_working.md).
The reserve hypotheses are stated in full in the next section.

## Retained reserve

Let `G` be seven-connected, with a vertex `u` whose neighbourhood is
the anticomplete union of a triangle `P={p1,p2,p3}` and a four-clique
`D={r,q1,q2,q3}`. Let `R` and `F` be a minimum reserve, as follows. `R` is connected,
contains `r`, avoids every other vertex of
`P union D`, and is adjacent to both `p1` and `p2`; `F` is an induced
`p3`--`q3` path, disjoint from `R` and from `{p1,p2,q1,q2}`; and
`|R union F|` is minimum over all such choices and all labellings of
`P` and `D`. Write `H0=G-({u} union R union F)`. Absence of a `K4`
minor of `H0` rooted at `p1,p2,q1,q2` is the reason for passing to a
web: by Fabila-Monroy–Wood, Theorem 15, `H0` is a spanning subgraph of
a web with outer order `(p1,p2,q1,q2)`. The actual edge `p1p2` then
lies in a unique internal facial triangle `p1p2g` of the completed
skeleton. The rooted-minor obstruction itself is not reproved here.

Throughout, branch sets are vertex-disjoint connected subgraphs of the
actual graph `G`. No completion edge is used as a contact.

## The two-vertex cell

Let `X={v,w}` be an actual cell component on that face, with `vw` an
edge, with no neighbour in `R`, and with at least four neighbours on
`F`. Minimum degree at least seven, which follows from
seven-connectivity, forces the following shape.

The only possible neighbours of `v` outside `X` are `p1,p2,g` and
vertices of `F`. A vertex of `X` adjacent to two vertices `y,z` of `F`
whose open `F`-interval has at least two vertices would replace that
interval by the single vertex, strictly decreasing `|F|` and leaving
`R` and every root contact intact. Thus the `F`-neighbours of `v` are
pairwise at distance at most two, so they form a consecutive block of
size at most three. At least three are required to reach degree seven
once `w,p1,p2,g` are counted, and four do not fit in such a block.
Hence `v` is adjacent to all three of `p1,p2,g` and to exactly three
`F`-vertices. The same holds for `w`.

A neighbour of `v` and a neighbour of `w` are at `F`-distance at most
three, because the path through the edge `vw` has two internal
vertices. The two blocks therefore lie in a four-vertex subpath of
`F`, and their union has size at least four, so the union is exactly
four consecutive vertices `y1<y2<y3<y4` of `F`. The only consecutive
blocks of size three with that union are

    {y1,y2,y3} and {y2,y3,y4}.

Both vertices of `X` are adjacent to `y2` and to `y3`. Label `v` the
vertex adjacent to `y1` and `w` the vertex adjacent to `y4`.

## Model when g meets the opposite clique off F and R

Suppose there is a `g`--`{q1,q2}` path `Pi` in

    G-({u,p1,p2} union X union V(F) union V(R)).

Let `B_u={u,q1,q2} union V(Pi)`, let `B_L` be the vertex set of the
subpath `F[p3,y2]`, and let `B_R=V(R) union V(F[y3,q3])`. The seven
branch sets

    B_u, {p1}, {p2}, B_L, B_R, {v}, {w}

are a `K7` model.

`B_u` is connected because `Pi` meets `{q1,q2}`, those two vertices are
adjacent, and `u` is adjacent to both. `B_L` is a subpath. `B_R` is
connected because `F[y3,q3]` contains `q3`, `r` lies in `R`, and `rq3`
is a clique edge of `D`. The seven sets are disjoint: `Pi` was chosen
to avoid `u`, both displayed `P`-roots, `X`, `F` and `R`, while `y2y3`
separates the two `F` pieces.

The contacts are actual edges:

- `B_u` meets `{p1}`, `{p2}`, `B_L` and `B_R` at `u`, through `up1`,
  `up2`, `up3` and either `ur` or `uq3`.
- `B_u` meets `{v}` and `{w}` because both are adjacent to `g` and `g`
  lies on `Pi`.
- `{p1}` meets `{p2}` by the triangle edge, meets `B_L` at `p3`, meets
  `B_R` because `R` was chosen adjacent to `p1`, and meets `{v}` and
  `{w}` by the gate edges. The `p2` row is symmetric, using that `R`
  is adjacent to `p2`.
- `B_L` meets `B_R` by the edge `y2y3`. It meets `{v}` inside
  `{y1,y2}` and `{w}` at `y2`.
- `B_R` meets `{v}` at `y3` and `{w}` inside `{y3,y4}`.
- `{v}` meets `{w}` by the cell edge.

In particular this applies when `g` itself lies in `{q1,q2}`, with `Pi`
the one-vertex path, and when `g` is adjacent to `q1` or to `q2`. It
also applies when `F` has vertices outside `{y1,y2,y3,y4}`: those
vertices stay on `B_L` or `B_R` according to the cut `y2y3`.

The same seven sets with the names `q1,q2` exchanged remain a model
when the outer order makes the third vertex of the `p1p2` face play
the role used here by either clique vertex.

## Model when the gate meets both sides of a four-vertex path

Now suppose `F` itself is the four-vertex path `p3-y2-y3-q3`, so
`y1=p3` and `y4=q3`, and suppose `g` is adjacent to both `y2` and
`q3`. The seven branch sets

    {u,q1,q2,q3} union V(R), {p1}, {p2}, {p3,y2}, {y3,v}, {w}, {g}

are a `K7` model.

The large set is connected because `{u} union D` is connected and `R`
contains `r`, which is adjacent to `q3`. It is disjoint from the other
six sets. `{y3,v}` is connected by the gate window, and `{p3,y2}` is an
edge of `F`. The contacts that do not already appear in the previous
model are:

- `g` meets the large set at `q3`, meets `{p1}` and `{p2}` by the face
  triangle, meets `{p3,y2}` at `y2`, and meets `{v}` and `{w}` by the
  cell edges;
- `{w}` meets the large set at `q3` and meets `{p3,y2}` at `y2`;
- `{y3,v}` meets the large set by the edge `y3q3`.

Adjacency of `g` to both `p3` and `q3` is not an alternative hypothesis:
those two vertices have two vertices of `F` between them, so the path
through `g` would be a shorter `p3`--`q3` path and would contradict
minimality of the reserve. Adjacency to `y2` and `q3` does not shorten
`F`, because exactly one vertex lies between them.

The first two models were checked by enumerating the twenty-one
adjacencies on the corresponding abstract graphs, including a path `F`
with extra internal vertices and a skeleton path `g-h-q1` of length
two. The third model was returned by an exhaustive search of its
fourteen-vertex graph and then checked directly on the same pairs.
Those checks are scratch code and are not part of the argument.

## Model when g meets the whole initial segment of a four-vertex path

Suppose again that `F` is `p3-y2-y3-q3`, and that `g` is adjacent to all
three of `p3,y2,y3` and to neither `q3` nor any vertex of `R`. The
seven branch sets

    {u,y3,q1,q2,q3} union V(R), {p1}, {p2}, {p3}, {y2,w}, {v}, {g}

are a `K7` model. The large set is connected by `y3q3`, the clique on
`D` and the edge from `r` into `R`. The set `{y2,w}` is an edge.
Contacts of `g` use `gy3` into the large set, `gp1`, `gp2`, `gp3` and
the two cell edges. The vertex `w` meets the large set at `q3` and
meets `{p3}` by `p3y2`. The vertex `v` meets the large set at `y3`,
meets `{p3}` by the left window, and meets `{y2,w}` at `y2`. No pair
depends on an edge from `g` to `R` or to `q3`.

These three `F`-adjacencies do not shorten the reserve: each pair among
`p3,y2,y3` has at most one vertex of `F` strictly between its ends.

## What this removes, and the contact that is still open

Thus a two-vertex cell on the face `p1p2g`, with no neighbour in `R`
and with at least four neighbours on `F`, yields a `K7` minor in each
of these situations:

- `g` has a `{q1,q2}`-path avoiding `u`, `p1`, `p2`, the cell, `F` and
  `R`;
- `F` has four vertices and `g` is adjacent to `q3` and to `y2`;
- `F` has four vertices and `g` is adjacent to `p3`, `y2` and `y3`.

Seven-connectivity forces some `g`--`{q1,q2}` path in
`G-{u,p1,p2,v,w}`, since otherwise those five vertices separate `g`
from `{q1,q2}`. That path may enter `F` or `R`, so it need not be the
path the first model uses.

On the fourteen-vertex graph formed by `u`, the two cliques, a
connector `R={r,s}`, the four-vertex path `F`, the cell and `g`, an
exhaustive assignment of branch sets found no `K7` in any of the
following graphs: `g` adjacent only to `p1,p2,v,w`; the same plus
`q3`; the same plus `y3`; and the four graphs in which the three
further neighbours of `g` are chosen from `{y3,q3,r,s}`. The same
search found the third model above when those three neighbours are
`p3,y2,y3`. These absences are properties of those fourteen-vertex
graphs. They are not barriers for a seven-connected host, whose
minimum degree still has to be supplied at the other vertices, but
they show that the three models do not cover a gate whose only extra
neighbours lie in `{y3,q3} union R`.

Larger cell components, cells on a different face, that remaining
gate neighbourhood, and the rest of the split-clique case stay open.
No induction or colouring lift is asserted.
