# A Kempe \(K_4\) on the non-repeated roots

**Status:** working deduction; no separate audit. This does not close either
exceptional degree-seven case or `HC_7`. It is independent of the prism-exchange
and contraction arguments. The gap is stated at the end.

## Statement

Let `H` be a finite simple graph with a proper five-colouring, and let
`P={p0,p1,p2}` and `Q={q0,q1,q2}` be vertex-disjoint literal triangles in
`H`. Edges between `P` and `Q` are allowed. Write `T=P union Q`, and assume
that all five colours appear on `T`.

Then, after labelling as below, the bipartite contractibility theorem
supplies four disjoint connected bags

    B1 ni p1,  B2 ni p2,  C1 ni q1,  C2 ni q2,

contained in the union `W` of four explicitly chosen paths, and pairwise
adjacent. Either

1. `H-W` contains a `p0`--`q0` path, and the vertex set of any such path is
   a fifth bag giving a `K5` model whose five bags all meet `T`; or
2. `W` separates `p0` from `q0`.

No connectivity, criticality, or prism hypothesis is used. Outcome 1 is a
`T`-meeting `K5`. Outcome 2 is unresolved.

## The repeated pair and the four paths

A triangle is rainbow, so the unique repeated colour on `T` occupies one
vertex of `P` and one vertex of `Q`, and those two vertices are nonadjacent.
Label so that `p0` and `q0` have colour `0`, `p1` has colour `1`, `p2` has
colour `2`, `q1` has colour `3` and `q2` has colour `4`.

Consider the four pairs `p1q1`, `p1q2`, `p2q1` and `p2q2`. If the pair is an
edge of `H`, take that edge as its path. If not, the two vertices lie in one
bichromatic component of their two colours. Indeed, the only vertices of `T`
carrying one of those two colours are the two endpoints: `p0` and `q0` have
colour `0`. Swapping a component that contains exactly one endpoint replaces
that endpoint's colour by the other and deletes the vacated colour from `T`.

A vertex has one colour, so it lies only on those of the four paths whose
colour pair contains that colour. Any two such target pairs share the unique
endpoint of that colour. Paths of disjoint colour pairs are disjoint. The
four paths are therefore a `K_{2,2}`-scheme in the sense of the
[bipartite contractibility theorem](../results/bipartite_contractibility_via_matroid_reduction.md).

## The fifth bag

That theorem returns the four bags above, inside the union of the scheme
paths. The triangle edges `p1p2` and `q1q2` supply the two shore adjacencies
which the scheme does not contain, so the bags are pairwise adjacent. No
scheme path uses colour `0`, hence `p0` and `q0` lie outside `W`.

The edges `p0p1`, `p0p2`, `q0q1` and `q0q2` meet the four bags. In outcome 1
the `p0`--`q0` path in `H-W` is disjoint from all four bags, connected, and
adjacent to each of them. All five bags meet `T`.

## Colourfulness forbids an open repeated pair

Assume, in addition, that every proper five-colouring uses all five colours
on `T`. Outcome 1 is then the only route still available, and the following
constraints hold in the fixed colouring.

Say that `p0` is open for a colour `gamma in {3,4}` when no neighbour of
`p0` has colour `gamma`, and that `q0` is open for `delta in {1,2}` when no
neighbour of `q0` has colour `delta`. If `p0` is open for some `gamma` and
`q0` is open for some `delta`, recolour them with those colours. The two
vertices are nonadjacent, so the recolouring is proper, and colour `0`
leaves `T`. Thus at least one of `p0,q0` is closed: `p0` meets both colours
`3` and `4`, or `q0` meets both colours `1` and `2`.

Suppose `q0` is open for colour `1`. Let `K` be the `{0,4}`-component of
`p0`. Kempe-swap `K`.

- If `q2` is outside `K` and `q0` is inside `K`, then `p0` and `q0` both
  receive colour `4`, while `q2` keeps colour `4`. No vertex of `T` receives
  colour `0`.
- If `q2` and `q0` are both outside `K`, then `p0` receives colour `4` and
  `q0` stays colour `0`. The swap does not give `q0` a neighbour of colour
  `1`: a neighbour in `K` would already have put `q0` in `K`. Recolour `q0`
  with colour `1`. Again colour `0` leaves `T`.

The symmetric argument with colours `{0,3}` applies. Therefore `q1` lies in
the `{0,3}`-component of `p0` and `q2` lies in the `{0,4}`-component of
`p0`. If instead `p0` is the open vertex, the same reasoning links `q0` to
`p1` and to `p2`.

So in every colourful colouring, either both vertices of the repeated pair
are closed, or the open vertex's partner is joined to both vertices of the
opposite triangle by bichromatic paths.

## What remains

Those forced paths are not yet a fifth bag. On a `{0,4}`-path from `p0` to
`q2`, the first vertex in `W` has colour `4`. When that vertex lies in the
bag of `q2`, or the preceding colour-`0` vertex is adjacent to that bag, the
component of `p0` in `H-W` meets both opposite bags and is itself the fifth
bag. A shortest path can instead enter `W` at a colour-`4` vertex of the
`p1` or `p2` bag. Moving that vertex into the fifth bag, while keeping the
four bags connected and pairwise adjacent, is the unresolved step. The same
step remains when both vertices of the repeated pair are closed.

No connectivity hypothesis has been used. In particular the argument applies
to the five-coloured graph obtained by deleting the colour class of `r` from
a six-colouring of `G-u` in the degree-seven host. Outcome 1 still lifts
through that independent set and the vertex `u`, as in the
[colourful reduction](../results/hc7_two_triangle_colourful_reduction.md).
The entry step above is what blocks the lift. This is not a closure of the
two-triangle neighbourhood or of `HC_7`.
